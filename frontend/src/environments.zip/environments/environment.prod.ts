export const environment = {
  production: true,
  apiUrl: 'https://4mcictexoms.cmkis.online/api',
  assetPath: 'https://exoms.cmkis.online/',
  canvasJsAngularComponentPath: 'https://www.slarenasitsolutions.com/4mcictexoms/assets/js/canvasjs/canvasjs.angular.component'
};
